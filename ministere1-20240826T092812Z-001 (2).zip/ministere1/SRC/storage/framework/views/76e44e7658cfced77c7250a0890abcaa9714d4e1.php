

<?php $__env->startSection('head-title'); ?>
    Modifier Permission
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a href="#">Permissions</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a class="active" href="#">Modifier Permission : <?php echo e($permission->name); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('permissions')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <form action="<?php echo e(url('permissions/'.$permission->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-3">
            <label for="">Nom Permission :</label>
            <input type="text" name="name" value="<?php echo e($permission->name); ?>" class="form-control">
        </div>
        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
    </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/role-permission/permission/edit.blade.php ENDPATH**/ ?>