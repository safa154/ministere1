

<?php
    use Carbon\Carbon;
?>

<?php $__env->startSection('head-title'); ?>
    <?php echo e($service->nomS); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style type="text/css">
    .folder-card {
        width: 14%;
        height: 123px;
        background-color: #d3d3d3;
        border-radius: 10px;
        padding: 10px;
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: flex-start;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .folder-card .icon {
        font-size: 30px;
        color: orange;
    }

    .folder-card .badge {
        background-color: #316ce0;
        color: white;
        padding: 5px;
        border-radius: 5px;
        font-weight: lighter;
        font-size: 14px;
        position: absolute;
        top: 85px;
        left: 10px;
    }

    .folder-card .title {
        font-weight: lighter;
        font-size: 14px;
    }

    .folder-card .date {
        font-size: 10px;
        color: rgb(58, 56, 56);
    }

    .folder-card .dropdown {
        position: absolute;
        top: 10px;
        right: 10px;
        background: transparent;
        border: none;
    }

    .folder-card:hover {
        background-color: #bfbfbf;
    }

    .container {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    @media (max-width: 1200px) {
        .folder-card {
            width: 24%; /* 4 cards per row */
        }
    }

    @media (max-width: 992px) {
        .folder-card {
            width: 32%; /* 3 cards per row */
        }
    }

    @media (max-width: 768px) {
        .folder-card {
            width: 48%; /* 2 cards per row */
        }
    }

    @media (max-width: 576px) {
        .folder-card {
            width: 98%; /* 1 card per row */
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Services</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(route('services.show', $service->idS)); ?>" class="btn btn-primary">Retour</a>
    </div>

    


    <div class="container">
        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="folder-card">
                <div class="icon"><i class='bx bxs-folder'></i></div>
                <div class="title"><?php echo e($project->nomP); ?></div>
                <div class="date"><?php echo e(Carbon::parse($project->updated_at)->format('d/m/Y')); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/services/projets.blade.php ENDPATH**/ ?>