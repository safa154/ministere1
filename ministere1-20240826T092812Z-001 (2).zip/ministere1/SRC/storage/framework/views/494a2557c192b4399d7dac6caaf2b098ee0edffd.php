

<?php $__env->startSection('head-title'); ?>
    Modifier Partenaire
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a href="#">Partenaires</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a class="active" href="#">Modifier Partenaire : <?php echo e($partenaire->nomPa); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('partenaires')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <form action="<?php echo e(url('partenaires/'.$partenaire->idpa)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
            <div class="mb-3">
                <label for="">Nom Partenaire :</label>
                <input type="text" name="nomPa" value="<?php echo e($partenaire->nomPa); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label for="">Contact  Partenaire :</label>
                <input type="text" name="contactPa" value="<?php echo e($partenaire->contactPa); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label for="">Adresse  Partenaire :</label>
                <input type="text" name="adressePa" value="<?php echo e($partenaire->adressePa); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Enregistrer</button>
            </div>

    </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/partenaires/edit.blade.php ENDPATH**/ ?>