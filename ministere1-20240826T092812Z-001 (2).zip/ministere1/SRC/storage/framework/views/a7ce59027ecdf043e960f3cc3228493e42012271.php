

<?php
    use Carbon\Carbon;
?>

<?php $__env->startSection('head-title'); ?>
    Details Services
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('style'); ?>
    <style>
        .btn-container {
            display: flex;
            justify-content: flex-end; /* Aligne les boutons à droite */
            gap: 10px; /* Ajoute un espacement entre les boutons */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a href="#">Projets</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Details Projets</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('services')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <div class="container">
        <div class="row mx-4">
            <div class="card p-0">
                <div class="card-header">
                    <h5><?php echo e($service->nomS); ?></h5>
                </div>
                <div class="card-body">
                    <h5 class="card-title"></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($service->division->nomD); ?></h6>
                    <p class="card-text"><?php echo e($service->descriptionS); ?></p>
                    <div class="btn-container">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modifier service')): ?>
                            <a href="<?php echo e(url('services/'.$service->idS.'/edit')); ?>" class="btn btn-success">Modifier</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supprimer service')): ?>
                            <a href="<?php echo e(url('services/'.$service->idS.'/delete')); ?>" class="btn btn-danger">Supprimer</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voir projet')): ?>
                            <a href="<?php echo e(route('services.projets', $service->idS)); ?>" class="btn btn-info text-light">Projets</a>
                        <?php endif; ?>
                        
                    </div>
                </div>
                <div class="card-footer text-muted">
                    Dernière Modification: <?php echo e(Carbon::parse($service->updated_at)->format('d/m/Y')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/services/show.blade.php ENDPATH**/ ?>