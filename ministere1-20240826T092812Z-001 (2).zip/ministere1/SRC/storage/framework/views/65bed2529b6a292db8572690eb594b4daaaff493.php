

<?php
    use Carbon\Carbon;
?>

<?php $__env->startSection('head-title'); ?>
    Projets
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('style'); ?>
    <style type="text/css">
        .folder-card {
            width: 14%;
            height: 123px;
            background-color: #d3d3d3;
            border-radius: 10px;
            padding: 10px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: flex-start;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .folder-card .icon {
            font-size: 30px;
            color: orange;
        }

        .folder-card .badge {
            background-color: #316ce0;
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-weight: lighter;
            font-size: 14px;
            position: absolute;
            top: 85px;
            left: 10px;
        }

        .folder-card .title {
            font-weight: lighter;
            font-size: 14px;
        }

        .folder-card .date {
            font-size: 10px;
            color: rgb(58, 56, 56);
        }

        .folder-card .dropdown {
            position: absolute;
            top: 10px;
            right: 10px;
            background: transparent;
            border: none;
        }

        .folder-card:hover {
            background-color: #bfbfbf;
        }

        .folder-link {
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            justify-content: space-around;
            height: 100%;
            cursor: pointer;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        @media (max-width: 1200px) {
            .folder-card {
                width: 24%; /* 4 cards per row */
            }
        }

        @media (max-width: 992px) {
            .folder-card {
                width: 32%; /* 3 cards per row */
            }
        }

        @media (max-width: 768px) {
            .folder-card {
                width: 48%; /* 2 cards per row */
            }
        }

        @media (max-width: 576px) {
            .folder-card {
                width: 98%; /* 1 card per row */
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Projets</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <div class="containerr mt-3">
        <div class="row">
            <div id="search" class="d-flex justify-content-between align-items-center mb-3">
                <form action="<?php echo e(url('projets')); ?>" method="GET" class="d-flex" style="flex-grow: 1; max-width: 400px;">
                    <div class="form-input" style="flex-grow: 1;">
                        <input type="search" name="query" placeholder="Chercher..." value="<?php echo e(request('query')); ?>">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>                    
                    </div>
                </form>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter projet')): ?>
                    <a href="<?php echo e(url('projets/create')); ?>" class="btn btn-primary">Ajouter Projet</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container">
        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="folder-card">
                <a href="<?php echo e(route('projets.show', $projet->idP)); ?>" class="folder-link">
                    <div class="icon"><i class='bx bxs-folder'></i></div>
                    <div class="title"><?php echo e($projet->nomP); ?></div>
                    <div class="date"><?php echo e(Carbon::parse($projet->updated_at)->format('d/m/Y')); ?></div>
                </a>
                <div class="dropdown">
                    <button class="btn btn-link" type="button" id="dropdownMenuButton<?php echo e($projet->idP); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class='bx bx-dots-vertical-rounded' style='color:#0d0d0d'></i>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo e($projet->idP); ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voir projet')): ?>
                            <li><a href="<?php echo e(route('projets.show', $projet->idP)); ?>" class="dropdown-item">Show</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modifier projet')): ?>
                            <li><a href="<?php echo e(url('projets/'.$projet->idP.'/edit')); ?>" class="dropdown-item">Modifier</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supprimer projet')): ?>
                            <li><a href="<?php echo e(url('projets/'.$projet->idP.'/delete')); ?>" class="dropdown-item text-danger">Supprimer</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/projets/index.blade.php ENDPATH**/ ?>