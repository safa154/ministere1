

<?php $__env->startSection('head-title'); ?>
    Ajouter Document
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Documents</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Ajouter Document</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('documents')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('documents.import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="redirectTo" value="documents.index">
            <div class="mb-3">
                <label for="nomD" class="form-label">Nom du Document</label>
                <input type="text" name="nomD" class="form-control" id="nomD" required>
            </div>
            <div class="mb-3">
                <label for="typeD" class="form-label">Type du Document</label>
                <input type="text" name="typeD" class="form-control" id="typeD" value="Excel" required>
            </div>
            <div class="mb-3">
                <label for="idP" class="form-label">Nom du Projet</label>
                <div class="mb-3">
                    <select name="idP" class="form-select" aria-label="Default select example" required>
                        <option selected value="">Choisissez un Projet</option>
                        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($projet->idP); ?>"><?php echo e($projet->nomP); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="mb-3">
                <label for="excel_file" class="form-label">Importer le fichier Excel</label>
                <input type="file" name="excel_file" class="form-control" id="excel_file" required>
            </div>
            <button type="submit" class="btn btn-primary">Importer</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/documents/import.blade.php ENDPATH**/ ?>