

<?php $__env->startSection('head-title'); ?>
    Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Roles</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter role')): ?>
        <div class="d-flex justify-content-end align-items-center mb-3">
            <a href="<?php echo e(url('roles/create')); ?>" class="btn btn-primary">Ajouter Role</a>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-center mt-3">
        <table id="myTable" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($role->name); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modifier role')): ?>
                                <a href="<?php echo e(url('roles/'.$role->id.'/edit')); ?>" class="btn btn-outline-success">Modifier</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supprimer role')): ?>
                                <a href="<?php echo e(url('roles/'.$role->id.'/delete')); ?>" class="btn btn-outline-danger">Supprimer</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter permissions pour rôle')): ?>
                                <a href="<?php echo e(url('roles/'.$role->id.'/give-permissions')); ?>" class="btn btn-outline-primary">Ajouter/Modifier les Permissions</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/role-permission/role/index.blade.php ENDPATH**/ ?>