<!DOCTYPE html>
<html lang="fr">
<head>

    
    <title><?php echo $__env->yieldContent('title'); ?></title>

    
    <?php echo $__env->yieldContent('liens'); ?>
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery-3.7.0.min.js')); ?>"></script>


    
    


</head>

<body>

    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    
    
    

</body>
</html><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/layouts/index.blade.php ENDPATH**/ ?>