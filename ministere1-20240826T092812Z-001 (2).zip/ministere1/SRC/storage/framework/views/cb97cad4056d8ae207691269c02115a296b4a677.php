




<?php $__env->startSection('head-title'); ?>
    Recherche
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Recherche</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('documents.search')); ?>" method="GET">
        <div class="form-row d-flex justify-content-start align-items-center mb-3">
            <div class="col-6 mx-1">
                <input type="text" name="query" class="form-control" placeholder="Rechercher">
            </div>
            <div class="col-4 mx-1">
                <select name="file_filter" id="file_filter" class="form-control">
                    <option value="">Selectionnez un fichier</option>
                    <?php $__currentLoopData = $allDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($document->idD); ?>"><?php echo e($document->nomD); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-2 ms-4">
                <button class="btn btn-primary" type="submit">Rechercher</button>
            </div>
        </div>
    </form>

    <?php if(isset($results)): ?>
    <h4 class="text-center">Résultats de recherche</h4>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fileName => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span> Le fichier : <span class="badge rounded-pill text-bg-secondary mb-2"><?php echo e($fileName); ?></span></span>
        <?php if(count($rows) > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <!-- Utiliser for pour générer les en-têtes -->
                        <?php if(count($rows) > 0): ?>
                            <?php $firstRow = $rows[0]->toArray(); ?>
                            <?php for($i = 0; $i < count(array_keys($firstRow)); $i++): ?>
                                <th>Colonne <?php echo e($i+1); ?></th>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $rowArray = $row->toArray(); ?>
                            <?php for($i = 0; $i < count(array_keys($rowArray)); $i++): ?>
                                <td><?php echo e($rowArray[array_keys($rowArray)[$i]]); ?></td>
                            <?php endfor; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Aucune donnée trouvée dans ce fichier.</p>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/search.blade.php ENDPATH**/ ?>