

<?php $__env->startSection('head-title'); ?>
    Modifier Service
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a href="#">Services</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a class="active" href="#">Modifier Service
             : <?php echo e($service->nomS); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(route('services.show', $service->idS)); ?>" class="btn btn-primary">Retour</a>
    </div>

    <form action="<?php echo e(url('services/'.$service->idS)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-3">
            <label for="">Nom Service :</label>
            <input type="text" name="nomS" value="<?php echo e($service->nomS); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label for="">Description Service :</label>
            <textarea name="descriptionS" class="form-control" cols="30" rows="5" required><?php echo e($service->descriptionS); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="">Division :</label>
            <select name="idD" class="form-select" aria-label="Default select example" required>
                <option selected value="">Choisissez une division</option>
                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($division->idD); ?>" <?php echo e($service->idD == $division->idD ? 'selected' : ''); ?>><?php echo e($division->nomD); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>

    </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/services/edit.blade.php ENDPATH**/ ?>