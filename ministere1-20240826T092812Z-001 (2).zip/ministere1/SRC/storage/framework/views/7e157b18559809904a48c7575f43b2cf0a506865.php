

<?php $__env->startSection('head-title'); ?>
    Ajouter Utilisateur
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a class="active" href="#">Utilisateurs</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a class="active" href="#">Ajouter Utilisateur</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('users')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <form action="<?php echo e(url('users')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="mb-3">
            <label for="">Nom Utilisateur :</label>
            <input type="text" name="name" class="form-control">
        </div>

        <div class="mb-3">
            <label for="">Email Utilisateur :</label>
            <input type="text" name="email" class="form-control">
        </div>

        <div class="mb-3">
            <label for="">Mot de passe Utilisateur :</label>
            <input type="text" name="password" class="form-control">
        </div>

        <div class="mb-3">
            <label for="">Roles :</label>
            <select name="roles[]" class="form-control" multiple>
                <option value="" disabled>Selectionner les roles</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role); ?>"><?php echo e($role); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
    </form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/role-permission/user/create.blade.php ENDPATH**/ ?>