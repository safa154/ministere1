

<?php $__env->startSection('head-title'); ?>
    Modifier Document
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a href="<?php echo e(route('documents.index')); ?>">Documents</a>
    </li>
    <li><i class='bx bx-chevron-right' ></i></li>
    <li>
        <a class="active" href="#"><?php echo e($document->nomD); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(route('documents.index')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <form action="<?php echo e(route('documents.update', $document->idD)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-3">
            <label for="nomD" class="form-label">Nom du Document :</label>
            <input type="text" name="nomD" value="<?php echo e($document->nomD); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="typeD" class="form-label">Type Document :</label>
            <textarea name="typeD" class="form-control" cols="30" rows="5" required><?php echo e($document->typeD); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="idP" class="form-label">Nom du Projet</label>
            <select name="idP" class="form-select" required>
                <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($projet->idP); ?>" <?php echo e($document->idP == $projet->idP ? 'selected' : ''); ?>><?php echo e($projet->nomP); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="excel_file" class="form-label">Importer le fichier Excel</label>
            <input type="file" name="excel_file" class="form-control" id="excel_file">
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/documents/edit.blade.php ENDPATH**/ ?>