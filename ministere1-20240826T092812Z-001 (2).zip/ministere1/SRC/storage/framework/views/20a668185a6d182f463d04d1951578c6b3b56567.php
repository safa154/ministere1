

<?php $__env->startSection('head-title'); ?>
    Permissions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Permissions</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    

    
        

        <div class="mb-3">
            <div class="row mt-4">
                <?php for($i = 0; $i < count($permissions); $i += 4): ?>
                    <div class="row mb-3">
                        <?php for($j = $i; $j < $i + 4 && $j < count($permissions); $j++): ?>
                            <div class="col-md-3">
                                <div class="card border-primary">
                                    <div class="card-body">
                                        <h6 class="card-title text-primary"><?php echo e($permissions[$j]->name); ?></h6>
                                        <!-- Ajoutez plus d'informations ici si nécessaire -->
                                    </div>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/role-permission/permission/index.blade.php ENDPATH**/ ?>