

<?php $__env->startSection('head-title'); ?>
    Documents
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Documents</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter document')): ?>
        <div class="d-flex justify-content-end align-items-center mb-3">
            <a href="<?php echo e(url('documents/create')); ?>" class="btn btn-primary">Ajouter Document</a>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-center mt-2">
        <table id="myTable" class="table table-hover align-middle" style="width:100%; ">
            <thead class="table-light">
                <tr>
                    <th>Nom Document</th>
                    <th>Type</th>
                    <th>Nom Projet</th>
                    <th style="width: 30%">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($document->nomD); ?></td>
                        <td><?php echo e($document->typeD); ?></td>
                        <td><?php echo e($document->projet ? $document->projet->nomP : 'N/A'); ?></td>
                        <td style="width: 50%">
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modifier document')): ?>
                                <a href="<?php echo e(route('documents.edit', $document->idD)); ?>" class="btn btn-outline-success">Modifier</a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supprimer document')): ?>
                                <form action="<?php echo e(route('documents.destroy', $document->idD)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger">Supprimer</button>
                                </form>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('téléchargez document')): ?>
                                <a href="<?php echo e(route('documents.download', $document->idD)); ?>" class="btn btn-outline-info">Télécharger</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/documents/index.blade.php ENDPATH**/ ?>