

<?php $__env->startSection('head-title'); ?>
    Modifier Projet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a href="#">Services</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Modifier Projet : <?php echo e($projet->nomP); ?></a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('projets')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <form action="<?php echo e(url('projets/'.$projet->idP)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-3">
            <label for="">Nom Projet :</label>
            <input type="text" name="nomP" value="<?php echo e($projet->nomP); ?>" class="form-control">
        </div>

        <div class="mb-3">
            <label for="">Description Projet :</label>
            <textarea name="descriptionP" class="form-control" cols="30" rows="5" required><?php echo e($projet->descriptionP); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="">Service :</label>
            <select name="idS" class="form-select" aria-label="Default select example" required>
                <option selected value="">Choisissez une division</option>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($service->idS); ?>" <?php echo e($projet->idS == $service->idS ? 'selected' : ''); ?>><?php echo e($service->nomS); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="">Partenaires :</label>
            <div class="form-check">
                <?php $__currentLoopData = $partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partenaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input 
                        type="checkbox" 
                        name="idpa[]" 
                        value="<?php echo e($partenaire->idpa); ?>"
                        id="partenaire_<?php echo e($partenaire->idpa); ?>"
                        class="form-check-input"
                        <?php echo e($projet->partenaires->contains($partenaire->idpa) ? 'checked' : ''); ?>

                    >
                    <label class="form-check-label" for="partenaire_<?php echo e($partenaire->idpa); ?>">
                        <?php echo e($partenaire->nomPa); ?>

                    </label><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__errorArgs = ['idpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/projets/edit.blade.php ENDPATH**/ ?>