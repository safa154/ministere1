

<?php
    use Illuminate\Support\Str;
?>

<?php $__env->startSection('head-title'); ?>
    <?php echo e($division->nomD); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a href="#">Divisions</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Services</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('divisions')); ?>" class="btn btn-primary">Retour</a>
    </div>

    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card border-secondary mx-4 my-2" style="width: 18rem; overflow: hidden;">
            <div class="card-body text-secondary">
                <h5 class="card-title"><?php echo e($service->nomS); ?></h5>
                <p class="card-text">
                    <?php echo e(Str::limit($service->descriptionS, 50)); ?>

                    <span id="dots-<?php echo e($service->idS); ?>"></span>
                    <span id="more-<?php echo e($service->idS); ?>" style="display:none;"><?php echo e(substr($service->descriptionS, 50)); ?></span>
                </p>
                <?php if(strlen($service->descriptionS) > 50): ?>
                    <button onclick="toggleReadMore(<?php echo e($service->idS); ?>)" id="myBtn-<?php echo e($service->idS); ?>" class="btn btn-link p-0 text-primary">Read more</button>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

    <?php $__env->startSection('scripts'); ?>
        <script>
            function toggleReadMore(id) {
                var dots = document.getElementById("dots-" + id);
                var moreText = document.getElementById("more-" + id);
                var btnText = document.getElementById("myBtn-" + id);
            
                if (dots.style.display === "none") {
                    dots.style.display = "inline";
                    btnText.innerHTML = "Read more";
                    moreText.style.display = "none";
                } else {
                    dots.style.display = "none";
                    btnText.innerHTML = "Read less";
                    moreText.style.display = "inline";
                }
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/division/details.blade.php ENDPATH**/ ?>