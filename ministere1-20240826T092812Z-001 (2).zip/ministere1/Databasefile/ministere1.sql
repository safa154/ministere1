-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 08 août 2024 à 23:36
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ministere1`
--

-- --------------------------------------------------------

--
-- Structure de la table `divisions`
--

CREATE TABLE `divisions` (
  `idD` bigint(20) UNSIGNED NOT NULL,
  `nomD` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `divisions`
--

INSERT INTO `divisions` (`idD`, `nomD`, `created_at`, `updated_at`) VALUES
(1, 'Division du développement des talents digitaux', '2024-07-23 10:53:21', '2024-08-02 08:14:55'),
(2, 'Division du développement de la culture numérique', '2024-07-23 10:53:28', '2024-08-02 08:15:13'),
(4, 'Division du renforcement de l’inclusion numérique', '2024-07-31 09:11:20', '2024-08-02 08:15:39');

-- --------------------------------------------------------

--
-- Structure de la table `documents`
--

CREATE TABLE `documents` (
  `idD` bigint(20) UNSIGNED NOT NULL,
  `nomD` varchar(255) NOT NULL,
  `typeD` varchar(255) NOT NULL,
  `idP` bigint(20) UNSIGNED NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `documents`
--

INSERT INTO `documents` (`idD`, `nomD`, `typeD`, `idP`, `file_path`, `created_at`, `updated_at`) VALUES
(12, 'jobintech', 'Excel', 16, 'documents/wXY6UjcgC7lRWg624BdeMt9mrQmZ4e85IcsiWEy4.xlsx', '2024-08-02 08:36:30', '2024-08-02 08:36:30'),
(13, 'doc1', 'Excel', 16, 'documents/x4YBotj2T8DUB0QbjVWMgFY4sVR81Ee4NuT6jjXP.xlsx', '2024-08-02 08:36:57', '2024-08-06 17:46:42'),
(14, 'doc2', 'Excel', 16, 'documents/qYGQZ7JDHrPVGVUMZiyRlsHydvie1DWkBJB13yBJ.xlsx', '2024-08-02 08:37:10', '2024-08-02 08:37:10'),
(15, 'doc3', 'Excel', 16, 'documents/M4cUF3NnW21oZ6W5bQu9CzDquObSzYkBSv2oMzGi.xlsx', '2024-08-02 08:41:05', '2024-08-02 08:41:05'),
(16, 'document_prj1', 'Excel', 17, 'documents/9Bk3bFfveFBD8dGw3IbCCkzIEvPa98xZy250LAHT.xlsx', '2024-08-02 08:41:54', '2024-08-02 08:41:54'),
(17, 'document2_prj1', 'Excel', 17, 'documents/HpYBHZ9vQMMvmivgZ6VFZ1NlCDpaDu1q4xb8yhOm.xlsx', '2024-08-02 08:42:06', '2024-08-02 08:42:06'),
(18, 'document_prj2', 'Excel', 18, 'documents/36SdJAZnKYqqivGtC0EiXHkrwG2I9lqGAtlglRrz.xlsx', '2024-08-02 08:42:27', '2024-08-02 08:42:27'),
(19, 'doc_4', 'Excel', 20, 'documents/2VbVlgjSaojjOaS6yfxJzAjbgz8ibrahJFXUAYjs.xlsx', '2024-08-06 15:55:34', '2024-08-06 15:55:34');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '2014_10_12_000000_create_users_table', 1),
(14, '2014_10_12_100000_create_password_resets_table', 1),
(15, '2019_08_19_000000_create_failed_jobs_table', 1),
(16, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(17, '2024_07_18_220313_create_permission_tables', 1),
(18, '2024_07_23_110419_create_divisions_table', 1),
(19, '2024_07_23_123736_create_services_table', 2),
(20, '2024_07_24_090351_create_partenaires_table', 3),
(21, '2024_07_25_093521_create_projets_table', 4),
(23, '2024_07_25_200619_create_projets_partenaires_table', 5),
(24, '2024_07_29_132853_create_documents_table', 6),
(25, '2024_07_29_140253_add_file_path_to_documents_table', 7);

-- --------------------------------------------------------

--
-- Structure de la table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(3, 'App\\Models\\User', 1),
(3, 'App\\Models\\User', 3);

-- --------------------------------------------------------

--
-- Structure de la table `partenaires`
--

CREATE TABLE `partenaires` (
  `idpa` bigint(20) UNSIGNED NOT NULL,
  `nomPa` varchar(255) NOT NULL,
  `contactPa` varchar(255) NOT NULL,
  `adressePa` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `partenaires`
--

INSERT INTO `partenaires` (`idpa`, `nomPa`, `contactPa`, `adressePa`, `created_at`, `updated_at`) VALUES
(1, 'partenaire 1', '0612345678', 'adresse 1 adresse 1 adresse', '2024-07-24 12:16:53', '2024-08-01 19:11:33'),
(2, 'partenaire 2', '066100542', 'adresse 2', '2024-07-24 12:17:34', '2024-08-01 19:12:03'),
(4, 'partenaire 3', '05623148', 'partenaire 3', '2024-07-26 08:38:56', '2024-08-01 19:12:10');

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(7, 'voir utilisateur', 'web', '2024-08-01 11:38:45', '2024-08-01 11:38:45'),
(8, 'ajouter utilisateur', 'web', '2024-08-01 11:39:09', '2024-08-01 11:39:09'),
(9, 'modifier utilisateur', 'web', '2024-08-01 11:39:24', '2024-08-01 11:39:24'),
(10, 'supprimer utilisateur', 'web', '2024-08-01 11:39:35', '2024-08-01 11:39:35'),
(11, 'voir role', 'web', '2024-08-01 11:39:51', '2024-08-01 11:39:51'),
(12, 'ajouter role', 'web', '2024-08-01 11:39:59', '2024-08-01 11:39:59'),
(13, 'modifier role', 'web', '2024-08-01 11:40:07', '2024-08-01 11:40:07'),
(14, 'supprimer role', 'web', '2024-08-01 11:40:18', '2024-08-01 11:40:18'),
(15, 'ajouter permissions pour rôle', 'web', '2024-08-01 11:41:51', '2024-08-01 11:41:51'),
(16, 'voir division', 'web', '2024-08-01 11:42:17', '2024-08-01 11:42:17'),
(17, 'ajouter division', 'web', '2024-08-01 11:42:35', '2024-08-01 11:42:35'),
(18, 'modifier division', 'web', '2024-08-01 11:42:45', '2024-08-01 11:42:45'),
(19, 'supprimer division', 'web', '2024-08-01 11:42:55', '2024-08-01 11:42:55'),
(20, 'voir service', 'web', '2024-08-01 11:43:11', '2024-08-01 11:43:11'),
(21, 'ajouter service', 'web', '2024-08-01 11:43:19', '2024-08-01 11:43:19'),
(22, 'modifier service', 'web', '2024-08-01 11:43:32', '2024-08-01 11:43:32'),
(23, 'supprimer service', 'web', '2024-08-01 11:44:09', '2024-08-01 11:44:09'),
(24, 'voir projet', 'web', '2024-08-01 11:44:49', '2024-08-01 11:44:49'),
(25, 'ajouter projet', 'web', '2024-08-01 11:44:58', '2024-08-01 11:44:58'),
(26, 'modifier projet', 'web', '2024-08-01 11:45:11', '2024-08-01 11:45:11'),
(27, 'supprimer projet', 'web', '2024-08-01 11:45:20', '2024-08-01 11:45:20'),
(28, 'voir document', 'web', '2024-08-01 11:45:42', '2024-08-01 11:45:42'),
(29, 'ajouter document', 'web', '2024-08-01 11:45:51', '2024-08-01 11:45:51'),
(30, 'modifier document', 'web', '2024-08-01 11:45:58', '2024-08-01 11:45:58'),
(31, 'supprimer document', 'web', '2024-08-01 11:46:05', '2024-08-01 11:46:05'),
(32, 'téléchargez document', 'web', '2024-08-01 11:47:01', '2024-08-01 11:47:01'),
(33, 'voir partenaire', 'web', '2024-08-01 11:47:30', '2024-08-01 11:47:30'),
(34, 'ajouter partenaire', 'web', '2024-08-01 11:47:41', '2024-08-01 11:47:41'),
(35, 'modifier partenaire', 'web', '2024-08-01 11:47:48', '2024-08-01 11:47:48'),
(36, 'supprimer partenaire', 'web', '2024-08-01 11:47:54', '2024-08-01 11:47:54'),
(37, 'voir permission', 'web', '2024-08-01 11:49:35', '2024-08-01 11:49:35');

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `projets`
--

CREATE TABLE `projets` (
  `idP` bigint(20) UNSIGNED NOT NULL,
  `nomP` varchar(255) NOT NULL,
  `descriptionP` text NOT NULL,
  `idS` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `projets`
--

INSERT INTO `projets` (`idP`, `nomP`, `descriptionP`, `idS`, `created_at`, `updated_at`) VALUES
(16, 'jobintech', 'Le programme Jobintech vise à créer un nouveau vivier de talents “job-ready“ en technologies digitales, afin de débloquer le potentiel du secteur IT.\r\nLes entreprises partenaires jouent un rôle clé dans ce programme en étant engagés à chaque étape de la chaine de valeur.\r\nL’objectif commun est de sécuriser les besoins spécifiques des entreprises IT tout en réduisant leurs coûts d’onboarding et de formation, permettant ainsi un meilleur développement du secteur.', 25, '2024-08-02 08:21:02', '2024-08-02 08:21:02'),
(17, 'projet 1', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 20, '2024-08-02 08:22:22', '2024-08-02 08:22:22'),
(18, 'projet 2', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 23, '2024-08-02 08:22:46', '2024-08-02 08:22:46'),
(19, 'projet 3', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 27, '2024-08-02 08:22:57', '2024-08-02 08:22:57'),
(20, 'projet 4', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 20, '2024-08-02 08:23:10', '2024-08-02 08:23:10'),
(21, 'projet 5', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 20, '2024-08-02 08:23:20', '2024-08-02 08:23:20'),
(22, 'projet 6', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 22, '2024-08-02 08:23:31', '2024-08-02 08:23:31'),
(23, 'projet 7', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 21, '2024-08-02 08:23:48', '2024-08-02 08:23:48'),
(24, 'projet 8', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 24, '2024-08-02 08:24:39', '2024-08-02 08:24:39'),
(25, 'projet 9', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 25, '2024-08-02 08:24:56', '2024-08-02 08:24:56'),
(26, 'projet 10', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 25, '2024-08-02 08:25:08', '2024-08-02 08:25:08'),
(27, 'projet 11', 'Un projet est un ensemble de tâches à réaliser afin d\'atteindre un objectif défini, dans un contexte précis, dans les délais impartis et selon le niveau de qualité souhaité. Un projet est mené et géré par un groupe de personnes dont la taille peut évoluer de quelques collaborateurs à plusieurs centaines en fonction de sa complexité.', 27, '2024-08-02 08:25:19', '2024-08-02 08:25:19');

-- --------------------------------------------------------

--
-- Structure de la table `projets_partenaires`
--

CREATE TABLE `projets_partenaires` (
  `idP` bigint(20) UNSIGNED NOT NULL,
  `idPa` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `projets_partenaires`
--

INSERT INTO `projets_partenaires` (`idP`, `idPa`, `created_at`, `updated_at`) VALUES
(16, 1, NULL, NULL),
(16, 2, NULL, NULL),
(16, 4, NULL, NULL),
(17, 1, NULL, NULL),
(18, 2, NULL, NULL),
(19, 1, NULL, NULL),
(22, 1, NULL, NULL),
(22, 2, NULL, NULL),
(22, 4, NULL, NULL),
(23, 1, NULL, NULL),
(24, 4, NULL, NULL),
(25, 2, NULL, NULL),
(26, 1, NULL, NULL),
(27, 1, NULL, NULL),
(27, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'super-admin', 'web', '2024-07-23 10:36:57', '2024-07-23 10:36:57'),
(2, 'admin', 'web', '2024-07-23 10:37:03', '2024-07-23 10:37:03'),
(3, 'utilisateur', 'web', '2024-07-23 10:37:10', '2024-07-23 10:37:10');

-- --------------------------------------------------------

--
-- Structure de la table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(15, 1),
(16, 1),
(16, 3),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(20, 2),
(20, 3),
(21, 1),
(21, 2),
(22, 1),
(23, 1),
(24, 1),
(24, 3),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(28, 3),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(33, 3),
(34, 1),
(35, 1),
(36, 1),
(37, 1);

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

CREATE TABLE `services` (
  `idS` bigint(20) UNSIGNED NOT NULL,
  `nomS` varchar(255) NOT NULL,
  `descriptionS` text NOT NULL,
  `idD` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`idS`, `nomS`, `descriptionS`, `idD`, `created_at`, `updated_at`) VALUES
(20, 'Service du suivi des besoins du marché du travail dans le domaine numérique', 'Service du suivi des besoins du marché du travail dans le domaine numérique', 1, '2024-08-02 08:16:32', '2024-08-02 08:16:32'),
(21, 'Service du développement des formations dans de le secteur du numérique', 'Service du développement des formations dans de le secteur du numérique', 1, '2024-08-02 08:17:09', '2024-08-02 08:17:09'),
(22, 'Service des institutions et instituts de formation au numérique', 'Service des institutions et instituts de formation au numérique', 1, '2024-08-02 08:17:28', '2024-08-02 08:17:28'),
(23, 'Service de la promotion de la Recherche-Développement et de l’innovation en numérique', 'Service de la promotion de la Recherche-Développement et de l’innovation en numérique', 1, '2024-08-02 08:17:41', '2024-08-02 08:17:41'),
(24, 'Service du développement de la culture numérique', 'Service du développement de la culture numérique', 2, '2024-08-02 08:18:10', '2024-08-02 08:18:10'),
(25, 'Service du développement des compétences numériques', 'Service du développement des compétences numériques', 2, '2024-08-02 08:18:24', '2024-08-02 08:18:24'),
(26, 'Service du développement des centres numériques de proximité', 'Service du développement des centres numériques de proximité', 4, '2024-08-02 08:18:53', '2024-08-02 08:18:53'),
(27, 'Service du développement des services sociaux numériques', 'Service du développement des services sociaux numériques', 4, '2024-08-02 08:19:09', '2024-08-02 08:19:09');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'super', 'super@gmail.com', NULL, '$2y$10$lbBLP.AwLcXLsMEuFj/cWeN0V2/GJgXYU9A5rOgax9NRtsmTjXqY6', NULL, '2024-07-23 10:34:39', '2024-07-23 10:34:39'),
(2, 'admin', 'admin@gmail.com', NULL, '$2y$10$LdmUN/LnRBrYin947aw1e.BSjB.sDH69tndxiXryakc8r79AgpZZS', NULL, '2024-07-23 10:41:51', '2024-07-23 10:41:51'),
(3, 'utilisateur', 'user@gmail.com', NULL, '$2y$10$ShCLkJSmdeb5rItkqnu0dOxl8aJ60XVaP948buf3ak7hpEAiY.toi', NULL, '2024-07-23 10:42:00', '2024-07-23 10:42:00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`idD`);

--
-- Index pour la table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`idD`),
  ADD KEY `documents_idp_foreign` (`idP`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Index pour la table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Index pour la table `partenaires`
--
ALTER TABLE `partenaires`
  ADD PRIMARY KEY (`idpa`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `projets`
--
ALTER TABLE `projets`
  ADD PRIMARY KEY (`idP`),
  ADD KEY `projets_ids_foreign` (`idS`);

--
-- Index pour la table `projets_partenaires`
--
ALTER TABLE `projets_partenaires`
  ADD PRIMARY KEY (`idP`,`idPa`),
  ADD KEY `projets_partenaires_idpa_foreign` (`idPa`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Index pour la table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Index pour la table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`idS`),
  ADD KEY `services_idd_foreign` (`idD`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `idD` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `documents`
--
ALTER TABLE `documents`
  MODIFY `idD` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pour la table `partenaires`
--
ALTER TABLE `partenaires`
  MODIFY `idpa` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `projets`
--
ALTER TABLE `projets`
  MODIFY `idP` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `services`
--
ALTER TABLE `services`
  MODIFY `idS` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_idp_foreign` FOREIGN KEY (`idP`) REFERENCES `projets` (`idP`) ON DELETE CASCADE;

--
-- Contraintes pour la table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `projets`
--
ALTER TABLE `projets`
  ADD CONSTRAINT `projets_ids_foreign` FOREIGN KEY (`idS`) REFERENCES `services` (`idS`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `projets_partenaires`
--
ALTER TABLE `projets_partenaires`
  ADD CONSTRAINT `projets_partenaires_idp_foreign` FOREIGN KEY (`idP`) REFERENCES `projets` (`idP`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `projets_partenaires_idpa_foreign` FOREIGN KEY (`idPa`) REFERENCES `partenaires` (`idpa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_idd_foreign` FOREIGN KEY (`idD`) REFERENCES `divisions` (`idD`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
