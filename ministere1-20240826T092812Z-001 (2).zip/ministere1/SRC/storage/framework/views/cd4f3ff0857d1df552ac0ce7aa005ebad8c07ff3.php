

<?php $__env->startSection('head-title'); ?>
    Services
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('style'); ?>
    <style>
        .card-body {
            padding: 10px; /* Enlève le padding intérieur de la carte */
        }
    
        .card-body > * {
            margin-bottom: 1rem; /* Espacement entre les lignes */
        }
    
        .card-body > *:last-child {
            margin-bottom: 0; /* Enlève l'espacement après le dernier élément */
        }
    
        .btn-info {
            margin-left: auto; /* Aligne le bouton à droite */
            color: white;
            background-color: #54B1FC;
            border: none
        }
    
        .card {
            margin: 0 10px; /* Ajoute un espacement autour des cartes */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Services</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <div class="container mt-3">
        <div class="row">
            <div id="search" class="d-flex justify-content-between align-items-center mb-3">
                <form action="<?php echo e(url('services')); ?>" method="GET" class="d-flex" style="flex-grow: 1; max-width: 400px;">
                    <div class="form-input" style="flex-grow: 1;">
                        <input type="search" name="query" placeholder="Chercher..." value="<?php echo e(request('query')); ?>">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>                    
                    </div>
                </form>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter service')): ?>
                    <a href="<?php echo e(url('services/create')); ?>" class="btn btn-primary">Ajouter Service</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container mt-3">
        <div class="row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body d-flex flex-column">
                            <div>
                                <h5 class="card-title"><?php echo e($service->nomS); ?></h5>
                                <h6 class="card-subtitle mb-2 text-muted"><?php echo e($service->division->nomD); ?></h6>
                            </div>
                            <a href="<?php echo e(route('services.show', $service->idS)); ?>" class="btn btn-info mt-auto">Voir plus</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/services/index.blade.php ENDPATH**/ ?>