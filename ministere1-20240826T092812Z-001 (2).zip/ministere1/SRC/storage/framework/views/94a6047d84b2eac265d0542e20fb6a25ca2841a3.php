

<?php
    use Carbon\Carbon;
?>

<?php $__env->startSection('head-title'); ?>
    Details Projets
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a href="#">Projets</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Details Projets</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end align-items-center mb-3">
        <a href="<?php echo e(url('projets')); ?>" class="btn btn-primary">Retour</a>
    </div>
    <div class="container">
        <div class="row">
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Information Projet
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($projet->nomP); ?></h5>
                        <p style="font-size: 16px"><?php echo e($projet->descriptionP); ?></p>
                        <!-- Add more project details here as needed -->
                        <?php $__currentLoopData = $projet->partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partenaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge text-bg-secondary mx-1 mb-3"><?php echo e($partenaire->nomPa); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p class="card-text" style="font-size: 12px">Dernière Modification: <?php echo e(Carbon::parse($projet->updated_at)->format('d/m/Y')); ?></p>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Documents</button>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter document')): ?>
                            <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Importer</button>
                        <?php endif; ?>
                        
                    </div>
                </nav>
                <div class="tab-content mt-3" id="nav-tabContent">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voir document')): ?>
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" tabindex="0">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                    <th scope="col">Nom Document</th>
                                    <th scope="col">Type</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('téléchargez document')): ?>
                                        <th scope="col">Télécharger</th>
                                    <?php endif; ?>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($document->nomD); ?></td>
                                            <td><?php echo e($document->typeD); ?></td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('téléchargez document')): ?>
                                                <td>
                                                    <a href="<?php echo e(route('documents.download', $document->idD)); ?>" class="btn btn-outline-info">Télécharger</a>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter document')): ?>
                        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" tabindex="0">
                            <form action="<?php echo e(route('documents.import')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="redirectTo" value="projets.show">
                                <input type="hidden" name="idP" value="<?php echo e($projet->idP); ?>">
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Nom du Document :</label>
                                    <input type="text" name="nomD" class="form-control" id="exampleFormControlInput1" placeholder="nom Document">
                                </div>

                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Type du Document :</label>
                                    <input type="text" name="typeD" class="form-control" id="exampleFormControlInput1" value="Excel">
                                </div>

                                <div class="mb-3">
                                    <input type="hidden" name="idP" class="form-control" id="exampleFormControlInput1" value="<?php echo e($projet->idP); ?>">
                                </div>

                                <div class="mb-3">
                                    <label for="formFile" class="form-label">Importer un Document :</label>
                                    <div class="d-flex align-items-center">
                                        <input class="form-control me-2" name="excel_file" type="file" id="formFile">
                                        <button type="submit" class="btn btn-outline-primary">Importer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>

                        
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/projets/show.blade.php ENDPATH**/ ?>