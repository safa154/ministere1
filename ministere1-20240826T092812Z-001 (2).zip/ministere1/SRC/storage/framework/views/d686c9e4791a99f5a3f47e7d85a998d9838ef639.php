

<?php $__env->startSection('head-title'); ?>
    Divisions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('listeNav'); ?>
    <li>
        <a href="#">Dashboard</a>
    </li>
    <li><i class='bx bx-chevron-right'></i></li>
    <li>
        <a class="active" href="#">Divisions</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    <div class="container mt-3">
        <div class="row">
            <div id="search" class="d-flex justify-content-between align-items-center mb-3">
                <form action="<?php echo e(url('divisions')); ?>" method="GET" class="d-flex" style="flex-grow: 1; max-width: 400px;">
                    <div class="form-input" style="flex-grow: 1;">
                        <input type="search" name="query" placeholder="Chercher..." value="<?php echo e(request('query')); ?>">
                        <button type="submit" class="search-btn"><i class='bx bx-search'></i></button>
                    </div>
                </form>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter division')): ?>
                    <a href="<?php echo e(url('divisions/create')); ?>" class="btn btn-primary ml-3">Ajouter Division</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-center mt-3">
        <table id="example" class="table table-bordered table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>Nom Division</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if($divisions->isEmpty()): ?>
                    <tr>
                        <td colspan="2" class="text-center">Aucune division trouvée</td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($division->nomD); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('voir service')): ?>
                                    <a href="<?php echo e(route('divisions.details', $division->idD)); ?>" class="btn btn-outline-secondary">Services</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('modifier division')): ?>
                                    <a href="<?php echo e(url('divisions/'.$division->idD.'/edit')); ?>" class="btn btn-outline-success">Modifier</a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supprimer division')): ?>
                                    <a href="<?php echo e(url('divisions/'.$division->idD.'/delete')); ?>" class="btn btn-outline-danger">Supprimer</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asust\Desktop\ministere1\resources\views/division/index.blade.php ENDPATH**/ ?>